# Life OS – Android app
WebView wrapper around your HTML (app/src/main/assets/index.html).

## New launcher design
After login the app opens on an Android-style **home screen**: clock widget, Pomodoro widget, a grid of app icons (every old tab is now its own "app") and a dock with Contacts, Calendar, Notepad and Music. Tap an icon to open that app full-screen; the **‹** button, the **⌂** button or the phone's Back button returns to the home screen (Back on the home screen exits the app). Icon colours are fixed; the wallpaper follows the selected theme.

## Build the APK
**Android Studio:** File > Open this folder, let Gradle sync, then Build > Build APK(s).
APK appears in app/build/outputs/apk/debug/app-debug.apk. Copy to phone and install.

**GitHub (no install):** push this folder to a repo; Actions > Build APK > download artifact.

## Notes
- Data lives in the app's localStorage (private to the app; survives restarts, wiped on uninstall -> use Export first).
- Export JSON saves to Downloads. Import uses the system file picker.
- Print / PDF opens Android's print dialog (choose "Save as PDF").
- To update the app, replace assets/index.html and rebuild.

## New in this version
- **Contacts & Dialer** – keypad + saved contacts; 📞 calls directly (asks for Phone permission once, otherwise opens the dialer). Import from phone contacts is optional. Every call is logged in the day's record (Core Data, Insights) and contact names autocomplete in **Friends**, which also gets a 📞 button.
- **Notepad** – one note per day, stored inside that day's record (included in backups, shown in Core Data, searchable). Buttons add a time stamp, a task box or a summary of that day's data.
- **Calculator** – results can be sent to today's Expense items, Income or the Notepad.
- **Music** – "Allow file access & scan music" reads audio on the device (Music/audio permission) and plays it with the native player. Listening minutes and songs played feed Core Data, Time Analytics and Insights; favourites and play counts are in the backup. A Pomodoro session ending pauses the music.
- **Themes** – 18 new themes (27 in total) in Profile > Theme.
- Song list is cached on the device only (not in backups); re-scan after restoring on another phone.

## New in version 1.3
- **Calendar** (new tab, next to Planner) – month view, a day plan for the selected date, a quick-add form and an Upcoming list (7 / 14 / 30 days). Add events or reminders (optional end time, details, repeat daily / weekdays / weekly / monthly / yearly) or planner time blocks. Planner tasks live in the existing Planner data, so they show in both places; ticking an event as done, planner % done and your daily alarms / birthday all appear on the day plan. Everything feeds **Core Data** (new *Calendar* rows and a Calendar column in Daily details), **Insights**, the Notepad "+ Day summary", and is included in backups.
- **Notifications** – reminders for events (default 10 min before) and planner tasks (5 min before), a morning summary, an evening "log your day" reminder, a Pomodoro-finished alert and a backup-due nudge. Configure in **Backup & Settings > Notifications & background**. Android 13+ asks for notification permission on first start.
- **Background** – reminders are scheduled with Android's alarm manager, so they fire when the app is closed and are restored after a restart or update. While a Pomodoro session or music is running a small "running in the background" notification keeps the app alive; a Pomodoro that finishes while the app is closed is credited to Study & Time the next time you open it. A background check runs about every 6 hours to keep everything scheduled.
- Reminders are rebuilt from your data every few seconds, so editing, completing or deleting an item immediately updates what will fire. They cover the next 60 days; open the app occasionally to extend the window.
- For on-time delivery on some phones: *Settings > Allow exact alarms* and *Battery: let Life OS run in the background*.

## New in version 1.4
- **Usage % icon** (new app, next to Time Analytics) – shows what share of your time you spend in each app icon. Time is counted while an app is open on screen (the home screen and a switched-off screen are not counted) and stored per day, so it is included in backups. Use Day / Week / Month / Year and the date picker at the top; a donut chart and a list show time and % for every icon. *Clear usage data* resets it.
- **PDF button inside every icon** – the **PDF** button in the top bar of each app creates a real PDF file of *all* the data that app holds and saves it to Downloads (no print dialog). Apps with dated data ask for Day / Week / Month / Year / All time around the date selected at the top; Contacts, Calculator, Clock, Insights, My Summary, Profile and Settings export everything stored. Each PDF has a summary (total / average / highest), day-by-day tables and, where relevant, the detailed entries (expense items, friends & calls, planner tasks, calendar events, notes, bowel/sleep log, weight log, usage table...).
- PDF pages are drawn as images, so Hindi / Bengali text, ₹ and emoji print correctly, but the text inside the PDF is not selectable.
- The old *Print / PDF* button (system print dialog) is still there on the screens that had it.
