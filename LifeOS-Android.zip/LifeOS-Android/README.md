# Life OS – Android app
WebView wrapper around your HTML (app/src/main/assets/index.html).

## Build the APK
**Android Studio:** File > Open this folder, let Gradle sync, then Build > Build APK(s).
APK appears in app/build/outputs/apk/debug/app-debug.apk. Copy to phone and install.

**GitHub (no install):** push this folder to a repo; Actions > Build APK > download artifact.

## Notes
- Data lives in the app's localStorage (private to the app; survives restarts, wiped on uninstall -> use Export first).
- Export JSON saves to Downloads. Import uses the system file picker.
- Print / PDF opens Android's print dialog (choose "Save as PDF").
- To update the app, replace assets/index.html and rebuild.
