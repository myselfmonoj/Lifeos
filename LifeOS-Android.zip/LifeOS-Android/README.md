# Life OS – Android app
WebView wrapper around your HTML (app/src/main/assets/index.html).

## Build the APK
**Android Studio:** File > Open this folder, let Gradle sync, then Build > Build APK(s).
APK appears in app/build/outputs/apk/debug/app-debug.apk. Copy to phone and install.

**GitHub (no install):** push this folder to a repo; Actions > Build APK > download artifact.

## Notes
- Data lives in the app's localStorage (private to the app; survives restarts, wiped on uninstall -> use Export first).
- Export JSON saves to Downloads. Import uses the system file picker.
- Print / PDF opens Android's print dialog (choose "Save as PDF").
- To update the app, replace assets/index.html and rebuild.

## New in this version
- **Contacts & Dialer** – keypad + saved contacts; 📞 calls directly (asks for Phone permission once, otherwise opens the dialer). Import from phone contacts is optional. Every call is logged in the day's record (Core Data, Insights) and contact names autocomplete in **Friends**, which also gets a 📞 button.
- **Notepad** – one note per day, stored inside that day's record (included in backups, shown in Core Data, searchable). Buttons add a time stamp, a task box or a summary of that day's data.
- **Calculator** – results can be sent to today's Expense items, Income or the Notepad.
- **Music** – "Allow file access & scan music" reads audio on the device (Music/audio permission) and plays it with the native player. Listening minutes and songs played feed Core Data, Time Analytics and Insights; favourites and play counts are in the backup. A Pomodoro session ending pauses the music.
- **Themes** – 18 new themes (27 in total) in Profile > Theme.
- Song list is cached on the device only (not in backups); re-scan after restoring on another phone.
