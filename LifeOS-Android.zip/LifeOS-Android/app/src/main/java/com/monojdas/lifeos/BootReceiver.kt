package com.monojdas.lifeos

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Restart / app update / clock or time-zone change / exact-alarm permission change: put the alarms back. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Notifier.ensureChannels(ctx)
        Sched.reschedule(ctx)
        HeartbeatWorker.schedule(ctx)
    }
}
