package com.monojdas.lifeos

import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequest
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/** Runs every ~6 hours in the background: re-arms the alarms (in case the system dropped any) and nudges for overdue backups. */
class HeartbeatWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        Notifier.ensureChannels(applicationContext)
        Sched.reschedule(applicationContext)
        Sched.backupNudge(applicationContext)
        return Result.success()
    }

    companion object {
        fun schedule(ctx: Context) {
            val req = PeriodicWorkRequest.Builder(HeartbeatWorker::class.java, 6, TimeUnit.HOURS).build()
            androidx.work.WorkManager.getInstance(ctx)
                .enqueueUniquePeriodicWork("lifeos_heartbeat", ExistingPeriodicWorkPolicy.KEEP, req)
        }
    }
}
