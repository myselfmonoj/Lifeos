package com.monojdas.lifeos

import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

/**
 * Foreground service that exists only while a Pomodoro session or music is running, so Android keeps the app
 * (and its timers / player) alive after you switch to another app. It does no work itself.
 */
class KeepAliveService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val text = (intent?.getStringExtra("text") ?: "").ifBlank { "Running in the background" }
        Notifier.ensureChannels(this)
        val n = NotificationCompat.Builder(this, Notifier.CH_BG)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Life OS")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(Notifier.open(this, "", "", 7003))
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 34) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            else startForeground(ID, n)
        } catch (e: Exception) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    companion object { private const val ID = 7003 }
}
