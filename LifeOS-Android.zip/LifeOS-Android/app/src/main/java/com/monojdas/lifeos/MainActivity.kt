package com.monojdas.lifeos

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.print.PrintManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.util.Base64
import android.webkit.*
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    companion object {
        /** True while the app is on screen (the receiver skips alerts the app already shows itself). */
        @Volatile var visible = false
    }

    private lateinit var web: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    private val pickFile = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        val result = if (r.resultCode == RESULT_OK && data != null)
            WebChromeClient.FileChooserParams.parseResult(r.resultCode, data) else null
        filePathCallback?.onReceiveValue(result)
        filePathCallback = null
    }

    // ---- dialer / contacts / music support ----
    private var player: MediaPlayer? = null
    private var ready = false
    private var vol = 0.8f
    private val ui = Handler(Looper.getMainLooper())
    private var pendingPerm: ((Boolean) -> Unit)? = null
    private val askPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        val cb = pendingPerm; pendingPerm = null; cb?.invoke(ok)
    }

    // Injected after each page load: routes blob downloads and window.print() to native code.
    private val bridgeJs = """
        (function(){
          if(window.__lifeosPatched) return; window.__lifeosPatched = true;
          window.print = function(){ Android.print(); };
          var origClick = HTMLAnchorElement.prototype.click;
          HTMLAnchorElement.prototype.click = function(){
            if(this.download && this.href && this.href.indexOf('blob:') === 0){
              var name = this.download;
              fetch(this.href).then(function(r){return r.blob()}).then(function(b){
                var fr = new FileReader();
                fr.onloadend = function(){
                  Android.saveFile(name, b.type || 'application/octet-stream', String(fr.result).split(',')[1] || '');
                };
                fr.readAsDataURL(b);
              });
              return;
            }
            return origClick.apply(this, arguments);
          };
        })();
    """.trimIndent()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        Notifier.ensureChannels(this)
        HeartbeatWorker.schedule(this)
        Sched.reschedule(this)

        web = WebView(this)
        setContentView(web)
        ViewCompat.setOnApplyWindowInsetsListener(web) { v, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime()
            )
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            mediaPlaybackRequiresUserGesture = true
        }

        // Serve the bundled page from a stable https origin so localStorage persists reliably.
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.addJavascriptInterface(Bridge(), "Android")

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest) =
                loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (request.url.host == "appassets.androidplatform.net") return false
                startActivity(Intent(Intent.ACTION_VIEW, request.url))
                return true
            }

            override fun onPageFinished(view: WebView, url: String?) {
                view.evaluateJavascript(bridgeJs, null)
                handleIntent(intent)
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                v: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = cb
                return try {
                    pickFile.launch(params.createIntent()); true
                } catch (e: Exception) {
                    filePathCallback = null; false
                }
            }

            override fun onJsAlert(v: WebView, url: String?, message: String?, r: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(message)
                    .setPositiveButton(android.R.string.ok) { _, _ -> r.confirm() }
                    .setOnCancelListener { r.cancel() }.show()
                return true
            }

            override fun onJsConfirm(v: WebView, url: String?, message: String?, r: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(message)
                    .setPositiveButton(android.R.string.ok) { _, _ -> r.confirm() }
                    .setNegativeButton(android.R.string.cancel) { _, _ -> r.cancel() }
                    .setOnCancelListener { r.cancel() }.show()
                return true
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
            }
        })

        if (savedInstanceState != null) web.restoreState(savedInstanceState)
        else web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    private fun withPerm(p: String, cb: (Boolean) -> Unit) {
        if (ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED) cb(true)
        else { pendingPerm = cb; askPerm.launch(p) }
    }

    private fun js(code: String) = runOnUiThread { web.evaluateJavascript(code, null) }

    private fun jsData(fn: String, json: String) =
        js("window.$fn&&window.$fn(JSON.parse(${JSONObject.quote(json)}))")

    private fun pushState() {
        val p = player ?: return
        if (!ready) return
        try { js("window.onMusicTick&&onMusicTick(${p.currentPosition},${p.duration},${p.isPlaying})") } catch (e: Exception) {}
    }

    private val tick = object : Runnable {
        override fun run() { pushState(); if (player != null) ui.postDelayed(this, 500) }
    }

    private fun releasePlayer() {
        ui.removeCallbacks(tick)
        try { player?.release() } catch (e: Exception) {}
        player = null; ready = false
    }

    override fun onStart() { super.onStart(); visible = true }

    override fun onStop() { visible = false; super.onStop() }

    // A tapped notification carries the tab and date to open (the web layer waits until the passcode is entered).
    private fun handleIntent(i: Intent?) {
        if (i == null) return
        val go = i.getStringExtra("go") ?: return
        val dt = i.getStringExtra("dt") ?: ""
        i.removeExtra("go")
        if (go.isBlank()) return
        js("window.openFromNative&&openFromNative(${JSONObject.quote(go)},${JSONObject.quote(dt)})")
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onDestroy() {
        releasePlayer()
        if (isFinishing) stopService(Intent(this, KeepAliveService::class.java))
        super.onDestroy()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    inner class Bridge {
        @JavascriptInterface
        fun saveFile(name: String, mime: String, base64: String) {
            try {
                val bytes = Base64.decode(base64, Base64.DEFAULT)
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("Could not create file")
                contentResolver.openOutputStream(uri)!!.use { it.write(bytes) }
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Saved to Downloads: $name", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Save failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }

        @JavascriptInterface
        fun shareFile(name: String, json: String, mode: String, email: String) {
            try {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, "application/json")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("Could not create file")
                contentResolver.openOutputStream(uri)!!.use { it.write(json.toByteArray()) }
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "application/json"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    putExtra(Intent.EXTRA_SUBJECT, "Life OS backup")
                    if (mode == "mail" && email.isNotBlank()) putExtra(Intent.EXTRA_EMAIL, arrayOf(email))
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                runOnUiThread {
                    try {
                        if (mode == "drive") {
                            startActivity(Intent(send).setPackage("com.google.android.apps.docs"))
                        } else throw IllegalStateException()
                    } catch (e: Exception) {
                        try { startActivity(Intent.createChooser(send, "Send backup")) }
                        catch (e2: Exception) { toast("No app can receive the backup") }
                    }
                }
            } catch (e: Exception) {
                toast("Backup failed: ${e.message}")
            }
        }

        @JavascriptInterface
        fun setAlarm(hour: Int, minute: Int, label: String) = clock(
            Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, hour).putExtra(AlarmClock.EXTRA_MINUTES, minute)
                .putExtra(AlarmClock.EXTRA_MESSAGE, label).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )

        @JavascriptInterface
        fun setTimer(seconds: Int, label: String) = clock(
            Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                .putExtra(AlarmClock.EXTRA_MESSAGE, label).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )

        private fun clock(i: Intent) = runOnUiThread {
            try { startActivity(i); toast("Set in your clock app") }
            catch (e: Exception) { toast("No clock app found") }
        }

        private fun toast(m: String) = runOnUiThread {
            Toast.makeText(this@MainActivity, m, Toast.LENGTH_LONG).show()
        }

        // ---- phone dialer ----
        private fun cleanNum(s: String) = s.filter { it.isDigit() || it == '+' || it == '*' || it == '#' }

        private fun startTel(action: String, n: String) {
            try { startActivity(Intent(action, Uri.fromParts("tel", n, null))) }
            catch (e: Exception) { toast("This device can't place calls") }
        }

        @JavascriptInterface
        fun dial(number: String) = runOnUiThread {
            val n = cleanNum(number)
            if (n.isNotEmpty()) startTel(Intent.ACTION_DIAL, n)
        }

        @JavascriptInterface
        fun call(number: String) = runOnUiThread {
            val n = cleanNum(number)
            if (n.isNotEmpty()) withPerm(Manifest.permission.CALL_PHONE) { ok ->
                startTel(if (ok) Intent.ACTION_CALL else Intent.ACTION_DIAL, n)
            }
        }

        @JavascriptInterface
        fun importContacts() = runOnUiThread {
            withPerm(Manifest.permission.READ_CONTACTS) { ok ->
                if (!ok) { toast("Contacts permission denied"); return@withPerm }
                Thread {
                    try {
                        val arr = JSONArray()
                        val seen = HashSet<String>()
                        val ph = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
                        val nameCol = ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
                        val numCol = ContactsContract.CommonDataKinds.Phone.NUMBER
                        contentResolver.query(ph, arrayOf(nameCol, numCol), null, null, "$nameCol COLLATE NOCASE ASC")?.use { c ->
                            while (c.moveToNext() && arr.length() < 5000) {
                                val n = c.getString(0) ?: ""
                                val p = c.getString(1) ?: ""
                                if (p.isNotBlank() && seen.add(n + "|" + p.filter { it.isDigit() }))
                                    arr.put(JSONObject().put("n", n).put("p", p))
                            }
                        }
                        jsData("onPhoneContacts", arr.toString())
                    } catch (e: Exception) { toast("Import failed: ${e.message}") }
                }.start()
            }
        }

        // ---- music: scan device audio + native playback ----
        @JavascriptInterface
        fun musicScan() = runOnUiThread {
            val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
                       else Manifest.permission.READ_EXTERNAL_STORAGE
            withPerm(perm) { ok ->
                if (!ok) { js("window.onMusicDenied&&onMusicDenied()"); return@withPerm }
                Thread {
                    try {
                        val arr = JSONArray()
                        val base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                        val proj = arrayOf(
                            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
                            MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION
                        )
                        contentResolver.query(
                            base, proj, "${MediaStore.Audio.Media.IS_MUSIC}!=0", null,
                            "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
                        )?.use { c ->
                            while (c.moveToNext() && arr.length() < 5000) {
                                val id = c.getLong(0)
                                arr.put(JSONObject()
                                    .put("id", id.toString())
                                    .put("t", c.getString(1) ?: "")
                                    .put("a", c.getString(2) ?: "")
                                    .put("d", c.getLong(3) / 1000)
                                    .put("u", ContentUris.withAppendedId(base, id).toString()))
                            }
                        }
                        jsData("onMusicList", arr.toString())
                    } catch (e: Exception) { toast("Scan failed: ${e.message}") }
                }.start()
            }
        }

        @JavascriptInterface
        fun musicPlay(uri: String) = runOnUiThread {
            if (!uri.startsWith("content://media/")) return@runOnUiThread
            releasePlayer()
            try {
                val mp = MediaPlayer()
                mp.setAudioAttributes(
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
                )
                mp.setDataSource(this@MainActivity, Uri.parse(uri))
                mp.setVolume(vol, vol)
                mp.setOnPreparedListener { it.start(); ready = true; ui.removeCallbacks(tick); ui.post(tick) }
                mp.setOnCompletionListener { js("window.onMusicEnd&&onMusicEnd()") }
                mp.setOnErrorListener { _, _, _ -> releasePlayer(); js("window.onMusicErr&&onMusicErr()"); true }
                player = mp
                mp.prepareAsync()
            } catch (e: Exception) {
                releasePlayer(); js("window.onMusicErr&&onMusicErr()")
            }
        }

        @JavascriptInterface
        fun musicPause() = runOnUiThread { try { if (ready) player?.pause() } catch (e: Exception) {}; pushState() }

        @JavascriptInterface
        fun musicResume() = runOnUiThread { try { if (ready) player?.start() } catch (e: Exception) {}; pushState() }

        @JavascriptInterface
        fun musicSeek(ms: Int) = runOnUiThread { try { if (ready) player?.seekTo(ms) } catch (e: Exception) {}; pushState() }

        @JavascriptInterface
        fun musicStop() = runOnUiThread { releasePlayer() }

        @JavascriptInterface
        fun musicVol(pct: Int) = runOnUiThread {
            vol = pct.coerceIn(0, 100) / 100f
            try { player?.setVolume(vol, vol) } catch (e: Exception) {}
        }

        @JavascriptInterface
        fun openSettings() = runOnUiThread {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null)))
            } catch (e: Exception) { toast("Open Settings > Apps > Life OS > Permissions") }
        }

        // ---- notifications & background work ----
        @JavascriptInterface
        fun syncReminders(json: String) {
            try {
                val o = JSONObject(json)
                Sched.saveQueue(this@MainActivity, o.optJSONArray("items") ?: JSONArray(), o.optJSONObject("meta") ?: JSONObject())
                Sched.reschedule(this@MainActivity)
            } catch (e: Exception) { }
        }

        @JavascriptInterface
        fun scheduleOne(k: String, at: Double, title: String, body: String, ch: String, fg: Int) {
            try {
                Sched.putOne(
                    this@MainActivity,
                    JSONObject().put("k", k).put("at", at.toLong()).put("ti", title).put("bo", body)
                        .put("ch", ch).put("go", "").put("dt", "").put("fg", fg)
                )
                Sched.reschedule(this@MainActivity)
            } catch (e: Exception) { }
        }

        @JavascriptInterface
        fun cancelOne(k: String) {
            try {
                Sched.removeOne(this@MainActivity, k)
                Sched.reschedule(this@MainActivity)
            } catch (e: Exception) { }
        }

        @JavascriptInterface
        fun notifyNow(title: String, body: String) {
            if (!Notifier.enabled(this@MainActivity)) toast("Notifications are blocked - use \"App notification settings\"")
            else Notifier.post(this@MainActivity, 7001, title, body, "rem", "cal", "")
        }

        @JavascriptInterface
        fun notifAsk() = runOnUiThread {
            if (Build.VERSION.SDK_INT >= 33) {
                withPerm(Manifest.permission.POST_NOTIFICATIONS) { ok -> js("window.onNotifPerm&&onNotifPerm($ok)") }
            } else {
                js("window.onNotifPerm&&onNotifPerm(${NotificationManagerCompat.from(this@MainActivity).areNotificationsEnabled()})")
            }
        }

        @JavascriptInterface
        fun notifState(): String = try {
            JSONObject()
                .put("notif", Notifier.enabled(this@MainActivity))
                .put("exact", Sched.exactOk(this@MainActivity))
                .put("count", Sched.count(this@MainActivity))
                .toString()
        } catch (e: Exception) { "{}" }

        @JavascriptInterface
        fun exactSettings() = runOnUiThread {
            try {
                if (Build.VERSION.SDK_INT >= 31)
                    startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
                else toast("Exact alarms are already allowed on this Android version")
            } catch (e: Exception) { openSettings() }
        }

        @JavascriptInterface
        fun notifSettings() = runOnUiThread {
            try {
                startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
            } catch (e: Exception) { openSettings() }
        }

        @JavascriptInterface
        fun batterySettings() = runOnUiThread {
            try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
            catch (e: Exception) { openSettings() }
        }

        /** Runs a foreground service while a study timer / music is active so Android keeps the app alive in the background. */
        @JavascriptInterface
        fun keepAlive(on: Boolean, text: String) {
            try {
                val i = Intent(this@MainActivity, KeepAliveService::class.java)
                if (on) ContextCompat.startForegroundService(this@MainActivity, i.putExtra("text", text))
                else stopService(i)
            } catch (e: Exception) { }
        }

        @JavascriptInterface
        fun print() {
            runOnUiThread {
                val pm = getSystemService(PRINT_SERVICE) as PrintManager
                pm.print("Life OS", web.createPrintDocumentAdapter("Life OS"), null)
            }
        }
    }
}
