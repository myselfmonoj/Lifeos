package com.monojdas.lifeos

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

/** Notification channels + one place that builds and posts every Life OS notification. */
object Notifier {
    const val CH_REM = "lifeos_reminders"
    const val CH_REMS = "lifeos_reminders_song"
    const val CH_DIG = "lifeos_summary"
    const val CH_TMR = "lifeos_timers"
    const val CH_BG = "lifeos_background"
    const val CH_BAK = "lifeos_backup"

    fun ensureChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        fun mk(id: String, name: String, imp: Int, desc: String) {
            val c = NotificationChannel(id, name, imp)
            c.description = desc
            nm.createNotificationChannel(c)
        }
        mk(CH_REM, "Events & planner reminders", NotificationManager.IMPORTANCE_HIGH, "Calendar events and planner tasks")
        // same as the reminders channel, but silent: the song itself is played by SoundService
        val quiet = NotificationChannel(CH_REMS, "Reminders with your own song", NotificationManager.IMPORTANCE_HIGH)
        quiet.description = "Calendar and planner reminders whose sound is the song you picked"
        quiet.setSound(null, null)
        nm.createNotificationChannel(quiet)
        mk(CH_DIG, "Daily summary & log reminder", NotificationManager.IMPORTANCE_DEFAULT, "Morning summary and evening reminder to log your day")
        mk(CH_TMR, "Pomodoro & timers", NotificationManager.IMPORTANCE_HIGH, "Study session and break alerts")
        mk(CH_BG, "Running in background", NotificationManager.IMPORTANCE_LOW, "Shown while a study timer or music keeps running")
        mk(CH_BAK, "Backup reminder", NotificationManager.IMPORTANCE_DEFAULT, "Reminds you when a backup is due")
    }

    private fun channelFor(k: String) = when (k) {
        "dig" -> CH_DIG
        "tmr" -> CH_TMR
        "bak" -> CH_BAK
        else -> CH_REM
    }

    /** Tapping a notification opens the app (and, via [go]/[dt], the matching tab and date). */
    fun open(ctx: Context, go: String, dt: String, code: Int): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra("go", go)
            .putExtra("dt", dt)
        return PendingIntent.getActivity(ctx, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun enabled(ctx: Context) = NotificationManagerCompat.from(ctx).areNotificationsEnabled()

    fun post(ctx: Context, id: Int, title: String, body: String, ch: String, go: String, dt: String, song: Boolean = false) {
        ensureChannels(ctx)
        if (!enabled(ctx)) return
        val timer = ch == "tmr"
        val b = NotificationCompat.Builder(ctx, if (song && ch != "tmr") CH_REMS else channelFor(ch))
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(body.lineSequence().firstOrNull() ?: "")
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setContentIntent(open(ctx, go, dt, id))
            .setAutoCancel(true)
            .setCategory(if (timer) NotificationCompat.CATEGORY_ALARM else NotificationCompat.CATEGORY_REMINDER)
            .setPriority(if (ch == "dig" || ch == "bak") NotificationCompat.PRIORITY_DEFAULT else NotificationCompat.PRIORITY_HIGH)
        try {
            NotificationManagerCompat.from(ctx).notify(id, b.build())
        } catch (e: SecurityException) {
            // notification permission revoked meanwhile - nothing to show
        }
    }
}
