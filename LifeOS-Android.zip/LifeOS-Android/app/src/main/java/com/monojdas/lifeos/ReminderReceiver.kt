package com.monojdas.lifeos

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Alarm target: shows the notification, then schedules whatever is next in the queue. */
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val k = intent.getStringExtra("k") ?: return
        val fg = intent.getIntExtra("fg", 1)
        // fg == 0: skip while the app is open (the app already alerts for it itself, e.g. the Pomodoro timer)
        if (!(fg == 0 && MainActivity.visible)) {
            Notifier.post(
                ctx, k.hashCode(),
                intent.getStringExtra("ti") ?: "Life OS",
                intent.getStringExtra("bo") ?: "",
                intent.getStringExtra("ch") ?: "rem",
                intent.getStringExtra("go") ?: "",
                intent.getStringExtra("dt") ?: ""
            )
        }
        Sched.removeOne(ctx, k)
        Sched.reschedule(ctx)
    }
}
