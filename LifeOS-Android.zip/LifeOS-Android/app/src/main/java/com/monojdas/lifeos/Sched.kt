package com.monojdas.lifeos

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/**
 * Native reminder scheduler.
 *
 * The web layer works out every reminder from the app's data (calendar events, planner tasks, summaries...)
 * and hands the whole list over with [saveQueue]. The list is kept in SharedPreferences so it survives a
 * restart; [reschedule] turns the next [MAX_ALARMS] entries into AlarmManager alarms. Each time one fires,
 * [ReminderReceiver] removes it and calls [reschedule] again, so the following ones are picked up even if
 * the app is never opened. [BootReceiver] and [HeartbeatWorker] call it too.
 */
object Sched {
    private const val PREFS = "lifeos_native"
    private const val MAX_ALARMS = 40
    private const val GRACE_MS = 20L * 60 * 1000          // fire a missed reminder if it is at most 20 min late
    private const val BACKUP_AFTER_MS = 7L * 24 * 3600 * 1000

    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun load(c: Context, key: String): JSONArray =
        try { JSONArray(prefs(c).getString(key, "[]")) } catch (e: Exception) { JSONArray() }

    @Synchronized
    fun saveQueue(c: Context, items: JSONArray, meta: JSONObject) {
        prefs(c).edit().putString("queue", items.toString()).putString("meta", meta.toString()).apply()
    }

    /** One-off items set from the app (e.g. the Pomodoro end). Same key replaces the previous one. */
    @Synchronized
    fun putOne(c: Context, item: JSONObject) {
        val k = item.optString("k")
        val old = load(c, "extra")
        val out = JSONArray()
        for (i in 0 until old.length()) {
            val o = old.optJSONObject(i) ?: continue
            if (o.optString("k") != k) out.put(o)
        }
        out.put(item)
        prefs(c).edit().putString("extra", out.toString()).apply()
    }

    @Synchronized
    fun removeOne(c: Context, k: String) {
        for (key in arrayOf("queue", "extra")) {
            val old = load(c, key)
            val out = JSONArray()
            for (i in 0 until old.length()) {
                val o = old.optJSONObject(i) ?: continue
                if (o.optString("k") != k) out.put(o)
            }
            prefs(c).edit().putString(key, out.toString()).apply()
        }
    }

    fun count(c: Context): Int = load(c, "sched").length()

    fun exactOk(c: Context): Boolean {
        if (Build.VERSION.SDK_INT < 31) return true
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return am.canScheduleExactAlarms()
    }

    private fun pending(c: Context, k: String, o: JSONObject?, flags: Int): PendingIntent? {
        val i = Intent(c, ReminderReceiver::class.java)
            .setAction("com.monojdas.lifeos.REMIND")
            .setData(Uri.parse("lifeos://reminder/" + Uri.encode(k)))
        if (o != null) {
            i.putExtra("k", k)
            i.putExtra("ti", o.optString("ti"))
            i.putExtra("bo", o.optString("bo"))
            i.putExtra("ch", o.optString("ch"))
            i.putExtra("go", o.optString("go"))
            i.putExtra("dt", o.optString("dt"))
            i.putExtra("fg", o.optInt("fg", 1))
        }
        return PendingIntent.getBroadcast(c, k.hashCode(), i, flags or PendingIntent.FLAG_IMMUTABLE)
    }

    @Synchronized
    fun reschedule(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        // 1. cancel what was scheduled last time
        val prev = load(c, "sched")
        for (i in 0 until prev.length()) {
            val k = prev.optString(i)
            pending(c, k, null, PendingIntent.FLAG_NO_CREATE)?.let { am.cancel(it); it.cancel() }
        }

        // 2. merge the app's list with one-off items (one-off items win), earliest first
        val now = System.currentTimeMillis()
        val map = LinkedHashMap<String, JSONObject>()
        for (key in arrayOf("queue", "extra")) {
            val a = load(c, key)
            for (i in 0 until a.length()) {
                val o = a.optJSONObject(i) ?: continue
                val k = o.optString("k")
                if (k.isNotEmpty()) map[k] = o
            }
        }
        val due = map.values
            .filter { it.optLong("at") >= now - GRACE_MS }
            .sortedBy { it.optLong("at") }
            .take(MAX_ALARMS)

        // 3. schedule them
        val keys = JSONArray()
        for (o in due) {
            val k = o.optString("k")
            val at = maxOf(o.optLong("at"), now + 1500)
            val pi = pending(c, k, o, PendingIntent.FLAG_UPDATE_CURRENT) ?: continue
            try {
                if (exactOk(c)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } catch (e: SecurityException) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
            keys.put(k)
        }
        prefs(c).edit().putString("sched", keys.toString()).apply()
    }

    /** Called from the periodic worker: nudge once a day (between 09:00 and 21:00) when a backup is overdue. */
    fun backupNudge(c: Context) {
        val p = prefs(c)
        val meta = try { JSONObject(p.getString("meta", "{}")) } catch (e: Exception) { JSONObject() }
        if (meta.optInt("bk") != 1) return
        val now = System.currentTimeMillis()
        val last = meta.optLong("last")
        if (last > 0 && now - last < BACKUP_AFTER_MS) return
        if (now - p.getLong("bkNudge", 0L) < 24L * 3600 * 1000) return
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        if (hour < 9 || hour >= 21) return
        val body = if (last <= 0) "You haven't saved a Life OS backup yet. Settings > Save backup file."
                   else "It has been ${(now - last) / (24L * 3600 * 1000)} days since your last backup."
        Notifier.post(c, 7002, "💾 Backup due", body, "bak", "set", "")
        p.edit().putLong("bkNudge", now).apply()
    }
}
