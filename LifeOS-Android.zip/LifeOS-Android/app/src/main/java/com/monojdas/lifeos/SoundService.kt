package com.monojdas.lifeos

import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import java.io.File

/**
 * Plays the song the user picked for a reminder (a copy kept in filesDir/sounds) for up to 30 seconds.
 * Started by [ReminderReceiver] when a reminder fires; the notification has a Stop button.
 */
class SoundService : Service() {
    private var mp: MediaPlayer? = null
    private val h = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.getStringExtra("act") == "stop") { stopAll(); return START_NOT_STICKY }
        val name = File(intent?.getStringExtra("file") ?: "").name
        Notifier.ensureChannels(this)
        val stop = PendingIntent.getService(
            this, 7005, Intent(this, SoundService::class.java).putExtra("act", "stop"),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, Notifier.CH_BG)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Life OS reminder")
            .setContentText("Playing your reminder song")
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(Notifier.open(this, "cal", "", 7004))
            .addAction(0, "Stop", stop)
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 34) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            else startForeground(ID, n)
        } catch (e: Exception) { stopSelf(); return START_NOT_STICKY }
        play(File(filesDir, "sounds/$name"))
        return START_NOT_STICKY
    }

    private fun play(f: File) {
        h.removeCallbacksAndMessages(null)
        try { mp?.release() } catch (e: Exception) {}
        mp = null
        if (!f.exists()) { stopAll(); return }
        try {
            val p = MediaPlayer()
            p.setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            )
            p.setDataSource(f.absolutePath)
            p.setOnCompletionListener { stopAll() }
            p.setOnErrorListener { _, _, _ -> stopAll(); true }
            p.prepare()
            p.start()
            mp = p
            h.postDelayed({ stopAll() }, 30_000)
        } catch (e: Exception) { stopAll() }
    }

    private fun stopAll() {
        h.removeCallbacksAndMessages(null)
        try { mp?.release() } catch (e: Exception) {}
        mp = null
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (e: Exception) {}
        stopSelf()
    }

    override fun onDestroy() {
        try { mp?.release() } catch (e: Exception) {}
        mp = null
        super.onDestroy()
    }

    companion object {
        private const val ID = 7004
        fun exists(c: Context, file: String?): Boolean =
            !file.isNullOrBlank() && File(c.filesDir, "sounds/" + File(file).name).exists()
    }
}
